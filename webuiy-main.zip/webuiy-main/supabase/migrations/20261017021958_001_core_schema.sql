/*
# Core Schema - Truyen Viet (Story Reading Platform)

Creates the full database schema for a Vietnamese story reading website.
Tables are ordered so that referenced tables exist before functions/triggers that use them.

## New Tables
- profiles (user profile + role, linked to auth.users)
- genres (story categories)
- stories (story metadata)
- chapters (story chapters with full text content)
- story_genres (junction: stories <-> genres)
- bookmarks (user <-> story favorites)
- reading_history (user reading progress)

## Security
- Public read access to published stories/chapters/genres (anon + authenticated)
- Admin-only writes to content tables (via is_admin() SECURITY DEFINER function)
- Owner-scoped CRUD on profiles, bookmarks, reading_history
- role column protected: REVOKE UPDATE + trigger guard

## Notes
1. profiles created before is_admin() so the SQL function validates.
2. Chapter content is text type (up to 1GB) - no truncation of long content.
3. All FKs use ON DELETE CASCADE.
*/

-- ============================================================================
-- TABLE: profiles (must exist before is_admin function)
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'reader' CHECK (role IN ('reader', 'admin')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_own" ON public.profiles;
CREATE POLICY "profiles_select_own"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
CREATE POLICY "profiles_update_own"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

REVOKE UPDATE (role) ON public.profiles FROM authenticated;

-- ============================================================================
-- HELPER FUNCTION: is_admin() — now profiles exists
-- ============================================================================

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT role = 'admin' FROM public.profiles WHERE id = auth.uid()),
    false
  );
$$;

GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated, anon;

-- Trigger guard: prevents non-admins from changing profile.role
CREATE OR REPLACE FUNCTION public.guard_profile_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.role IS DISTINCT FROM OLD.role AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Không có quyền thay đổi vai trò người dùng';
  END IF;
  RETURN NEW;
END;
$$;

GRANT EXECUTE ON FUNCTION public.guard_profile_role() TO authenticated;

DROP TRIGGER IF EXISTS trg_guard_profile_role ON public.profiles;
CREATE TRIGGER trg_guard_profile_role
  BEFORE UPDATE OF role ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.guard_profile_role();

-- ============================================================================
-- TABLE: genres
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.genres (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  description text
);

ALTER TABLE public.genres ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "genres_select_public" ON public.genres;
CREATE POLICY "genres_select_public"
  ON public.genres FOR SELECT
  TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "genres_insert_admin" ON public.genres;
CREATE POLICY "genres_insert_admin"
  ON public.genres FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "genres_update_admin" ON public.genres;
CREATE POLICY "genres_update_admin"
  ON public.genres FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "genres_delete_admin" ON public.genres;
CREATE POLICY "genres_delete_admin"
  ON public.genres FOR DELETE
  TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- TABLE: stories
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.stories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  author text NOT NULL DEFAULT 'Khuyết danh',
  description text,
  cover_url text,
  status text NOT NULL DEFAULT 'ongoing' CHECK (status IN ('ongoing', 'completed', 'hiatus')),
  is_hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_stories_status ON public.stories(status);
CREATE INDEX IF NOT EXISTS idx_stories_created_at ON public.stories(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_stories_updated_at ON public.stories(updated_at DESC);

ALTER TABLE public.stories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "stories_select_public" ON public.stories;
CREATE POLICY "stories_select_public"
  ON public.stories FOR SELECT
  TO anon, authenticated
  USING (is_hidden = false);

DROP POLICY IF EXISTS "stories_select_admin" ON public.stories;
CREATE POLICY "stories_select_admin"
  ON public.stories FOR SELECT
  TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "stories_insert_admin" ON public.stories;
CREATE POLICY "stories_insert_admin"
  ON public.stories FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "stories_update_admin" ON public.stories;
CREATE POLICY "stories_update_admin"
  ON public.stories FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "stories_delete_admin" ON public.stories;
CREATE POLICY "stories_delete_admin"
  ON public.stories FOR DELETE
  TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- TABLE: chapters
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.chapters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id uuid NOT NULL REFERENCES public.stories(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL DEFAULT '',
  chapter_order integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
  word_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_chapters_story_order ON public.chapters(story_id, chapter_order);
CREATE INDEX IF NOT EXISTS idx_chapters_status ON public.chapters(status);

ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "chapters_select_public" ON public.chapters;
CREATE POLICY "chapters_select_public"
  ON public.chapters FOR SELECT
  TO anon, authenticated
  USING (
    status = 'published'
    AND EXISTS (
      SELECT 1 FROM public.stories
      WHERE stories.id = chapters.story_id
        AND stories.is_hidden = false
    )
  );

DROP POLICY IF EXISTS "chapters_select_admin" ON public.chapters;
CREATE POLICY "chapters_select_admin"
  ON public.chapters FOR SELECT
  TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "chapters_insert_admin" ON public.chapters;
CREATE POLICY "chapters_insert_admin"
  ON public.chapters FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "chapters_update_admin" ON public.chapters;
CREATE POLICY "chapters_update_admin"
  ON public.chapters FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "chapters_delete_admin" ON public.chapters;
CREATE POLICY "chapters_delete_admin"
  ON public.chapters FOR DELETE
  TO authenticated
  USING (public.is_admin());

-- Auto-compute word_count and updated_at on content change
CREATE OR REPLACE FUNCTION public.update_chapter_word_count()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.word_count := COALESCE(array_length(string_to_array(trim(NEW.content), ' '), 1), 0);
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_update_chapter_word_count ON public.chapters;
CREATE TRIGGER trg_update_chapter_word_count
  BEFORE INSERT OR UPDATE OF content ON public.chapters
  FOR EACH ROW
  EXECUTE FUNCTION public.update_chapter_word_count();

-- Touch story.updated_at when chapters change
CREATE OR REPLACE FUNCTION public.touch_story_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE public.stories SET updated_at = now() WHERE id = NEW.story_id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_touch_story_on_chapter_insert ON public.chapters;
CREATE TRIGGER trg_touch_story_on_chapter_insert
  AFTER INSERT ON public.chapters
  FOR EACH ROW
  EXECUTE FUNCTION public.touch_story_updated_at();

DROP TRIGGER IF EXISTS trg_touch_story_on_chapter_update ON public.chapters;
CREATE TRIGGER trg_touch_story_on_chapter_update
  AFTER UPDATE OF status ON public.chapters
  FOR EACH ROW
  EXECUTE FUNCTION public.touch_story_updated_at();

-- ============================================================================
-- TABLE: story_genres (junction)
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.story_genres (
  story_id uuid NOT NULL REFERENCES public.stories(id) ON DELETE CASCADE,
  genre_id uuid NOT NULL REFERENCES public.genres(id) ON DELETE CASCADE,
  PRIMARY KEY (story_id, genre_id)
);

CREATE INDEX IF NOT EXISTS idx_story_genres_genre ON public.story_genres(genre_id);

ALTER TABLE public.story_genres ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "story_genres_select_public" ON public.story_genres;
CREATE POLICY "story_genres_select_public"
  ON public.story_genres FOR SELECT
  TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "story_genres_insert_admin" ON public.story_genres;
CREATE POLICY "story_genres_insert_admin"
  ON public.story_genres FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "story_genres_delete_admin" ON public.story_genres;
CREATE POLICY "story_genres_delete_admin"
  ON public.story_genres FOR DELETE
  TO authenticated
  USING (public.is_admin());

-- ============================================================================
-- TABLE: bookmarks
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.bookmarks (
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  story_id uuid NOT NULL REFERENCES public.stories(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, story_id)
);

CREATE INDEX IF NOT EXISTS idx_bookmarks_user ON public.bookmarks(user_id);

ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "bookmarks_select_own" ON public.bookmarks;
CREATE POLICY "bookmarks_select_own"
  ON public.bookmarks FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "bookmarks_insert_own" ON public.bookmarks;
CREATE POLICY "bookmarks_insert_own"
  ON public.bookmarks FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "bookmarks_delete_own" ON public.bookmarks;
CREATE POLICY "bookmarks_delete_own"
  ON public.bookmarks FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ============================================================================
-- TABLE: reading_history
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.reading_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  story_id uuid NOT NULL REFERENCES public.stories(id) ON DELETE CASCADE,
  chapter_id uuid NOT NULL REFERENCES public.chapters(id) ON DELETE CASCADE,
  read_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reading_history_user ON public.reading_history(user_id, read_at DESC);
CREATE INDEX IF NOT EXISTS idx_reading_history_user_story ON public.reading_history(user_id, story_id);

ALTER TABLE public.reading_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "history_select_own" ON public.reading_history;
CREATE POLICY "history_select_own"
  ON public.reading_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "history_insert_own" ON public.reading_history;
CREATE POLICY "history_insert_own"
  ON public.reading_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "history_update_own" ON public.reading_history;
CREATE POLICY "history_update_own"
  ON public.reading_history FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "history_delete_own" ON public.reading_history;
CREATE POLICY "history_delete_own"
  ON public.reading_history FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ============================================================================
-- TRIGGER: auto-create profile on signup
-- ============================================================================

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, username)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

GRANT EXECUTE ON FUNCTION public.handle_new_user() TO authenticated, anon;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();