/*
# Security Hardening - Revoke EXECUTE on internal functions + fix search_path

## Changes
1. Revoke EXECUTE on `guard_profile_role()` from anon and authenticated — this is an internal trigger function, never meant to be called via REST API. Calling it directly could leak whether a user is admin.
2. Revoke EXECUTE on `handle_new_user()` from anon and authenticated — this is an internal trigger function fired by auth.users INSERT. Calling it via REST could allow inserting profiles for arbitrary users.
3. Fix mutable search_path on `update_chapter_word_count()` and `touch_story_updated_at()` trigger functions by setting `search_path = public`.

## Notes
- `is_admin()` stays executable by anon/authenticated because RLS policies on stories/chapters/genres call it, and those policies run for both anon and authenticated roles.
- These changes do NOT affect any table data, RLS policies, or the app's read/write flows.
*/

-- Revoke EXECUTE on internal trigger functions (not callable via REST API)
REVOKE EXECUTE ON FUNCTION public.guard_profile_role() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated;

-- Fix mutable search_path on trigger functions
CREATE OR REPLACE FUNCTION public.update_chapter_word_count()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.word_count := COALESCE(array_length(string_to_array(trim(NEW.content), ' '), 1), 0);
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.touch_story_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.stories SET updated_at = now() WHERE id = NEW.story_id;
  RETURN NEW;
END;
$$;
