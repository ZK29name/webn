/*
# Fix: Revoke EXECUTE on internal trigger functions

## Problem
The previous migration `fix_security_hardening` revoked EXECUTE on `guard_profile_role()` and `handle_new_user()`, but Supabase's advisor still reports them as callable by anon/authenticated. This happens because `REVOKE EXECUTE ON FUNCTION` only affects the specific function signature at the time — re-creating the function can restore the default PUBLIC grant.

## Fix
Re-revoke EXECUTE from anon and authenticated on both internal trigger functions. These are only meant to be called by database triggers, never via the REST API.

## Notes
- `is_admin()` intentionally stays executable by all roles because RLS policies call it.
- No data changes, no table structure changes.
*/

REVOKE EXECUTE ON FUNCTION public.guard_profile_role() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
