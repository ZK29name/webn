import { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, FileText, Eye, EyeOff, Trash2, Plus, Pencil, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Story, Chapter, Genre } from '@/lib/types';
import { STORY_STATUS_LABELS, STORY_STATUS_COLORS, CHAPTER_STATUS_LABELS } from '@/lib/types';
import { useAuth } from '@/lib/auth';
import { Loader, ErrorState, EmptyState } from '@/components/Feedback';
import { showToast } from '@/components/Toast';
import { formatDate, slugify } from '@/lib/utils';
import { ChapterEditor } from '@/components/ChapterEditor';

type Tab = 'stories' | 'chapters';

export default function AdminPage() {
  const { profile } = useAuth();
  const [tab, setTab] = useState<Tab>('stories');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stories, setStories] = useState<Story[]>([]);
  const [chapters, setChapters] = useState<(Chapter & { story_title: string })[]>([]);
  const [genres, setGenres] = useState<Genre[]>([]);
  const [editingStory, setEditingStory] = useState<Story | null>(null);
  const [showStoryForm, setShowStoryForm] = useState(false);
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);
  const [showChapterForm, setShowChapterForm] = useState(false);
  const [selectedStoryId, setSelectedStoryId] = useState<string>('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [storiesRes, genresRes] = await Promise.all([
        supabase.from('stories').select('*').order('updated_at', { ascending: false }),
        supabase.from('genres').select('*').order('name'),
      ]);

      if (storiesRes.error) throw storiesRes.error;
      if (genresRes.error) throw genresRes.error;

      setStories(storiesRes.data as Story[]);
      setGenres(genresRes.data as Genre[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Không thể tải dữ liệu');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const fetchChapters = useCallback(async (storyId: string) => {
    const { data, error: err } = await supabase
      .from('chapters')
      .select('*, stories!inner(title)')
      .eq('story_id', storyId)
      .order('chapter_order', { ascending: true });

    if (err) {
      showToast('error', 'Không thể tải chương');
      return;
    }

    setChapters((data as any[]).map((c) => ({ ...c, story_title: c.stories.title })));
  }, []);

  const toggleStoryVisibility = async (story: Story) => {
    const { error: err } = await supabase
      .from('stories')
      .update({ is_hidden: !story.is_hidden })
      .eq('id', story.id);

    if (err) {
      showToast('error', 'Không thể cập nhật');
      return;
    }
    setStories((prev) => prev.map((s) => (s.id === story.id ? { ...s, is_hidden: !s.is_hidden } : s)));
    showToast('success', story.is_hidden ? 'Đã hiển thị truyện' : 'Đã ẩn truyện');
  };

  const toggleChapterStatus = async (chapter: Chapter) => {
    const newStatus = chapter.status === 'published' ? 'draft' : 'published';
    const { error: err } = await supabase
      .from('chapters')
      .update({ status: newStatus })
      .eq('id', chapter.id);

    if (err) {
      showToast('error', 'Không thể cập nhật');
      return;
    }
    setChapters((prev) => prev.map((c) => (c.id === chapter.id ? { ...c, status: newStatus } : c)));
    showToast('success', newStatus === 'published' ? 'Đã xuất bản chương' : 'Đã chuyển về bản nháp');
  };

  const deleteStory = async (story: Story) => {
    if (!confirm(`Xóa truyện "${story.title}"? Tất cả chương sẽ bị xóa theo.`)) return;
    const { error: err } = await supabase.from('stories').delete().eq('id', story.id);
    if (err) {
      showToast('error', 'Không thể xóa truyện');
      return;
    }
    setStories((prev) => prev.filter((s) => s.id !== story.id));
    showToast('success', 'Đã xóa truyện');
  };

  const deleteChapter = async (chapter: Chapter) => {
    if (!confirm(`Xóa "${chapter.title}"?`)) return;
    const { error: err } = await supabase.from('chapters').delete().eq('id', chapter.id);
    if (err) {
      showToast('error', 'Không thể xóa chương');
      return;
    }
    setChapters((prev) => prev.filter((c) => c.id !== chapter.id));
    showToast('success', 'Đã xóa chương');
  };

  if (loading) return <Loader />;
  if (error) return <ErrorState message={error} onRetry={fetchData} />;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-1">Quản trị nội dung</h1>
        <p className="text-sm text-gray-500">Xin chào, {profile?.username} — bạn có quyền quản trị</p>
      </div>

      <div className="flex items-center gap-1 border-b border-gray-200 mb-6">
        <button
          onClick={() => setTab('stories')}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
            tab === 'stories' ? 'border-brand-600 text-brand-600' : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <BookOpen className="h-4 w-4" />
          Truyện ({stories.length})
        </button>
        <button
          onClick={() => setTab('chapters')}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
            tab === 'chapters' ? 'border-brand-600 text-brand-600' : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <FileText className="h-4 w-4" />
          Chương
        </button>
      </div>

      {tab === 'stories' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-semibold text-gray-900">Danh sách truyện</h2>
            <button
              onClick={() => { setEditingStory(null); setShowStoryForm(true); }}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors"
            >
              <Plus className="h-4 w-4" /> Thêm truyện
            </button>
          </div>

          {stories.length === 0 ? (
            <EmptyState icon={BookOpen} title="Chưa có truyện nào" />
          ) : (
            <div className="space-y-2">
              {stories.map((story) => (
                <div
                  key={story.id}
                  className="flex items-center gap-3 bg-white rounded-xl border border-gray-100 p-4 hover:border-gray-200 transition-colors"
                >
                  <div className="w-10 h-14 rounded-lg overflow-hidden bg-gray-100 shrink-0">
                    {story.cover_url ? (
                      <img src={story.cover_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <BookOpen className="h-5 w-5 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <Link
                      to={`/truyen/${story.slug}`}
                      className="font-semibold text-gray-900 text-sm hover:text-brand-600 transition-colors truncate block"
                    >
                      {story.title}
                    </Link>
                    <div className="flex items-center gap-2 text-xs text-gray-400 mt-0.5">
                      <span className={`px-1.5 py-0.5 rounded ${STORY_STATUS_COLORS[story.status]}`}>
                        {STORY_STATUS_LABELS[story.status]}
                      </span>
                      <span>{formatDate(story.updated_at)}</span>
                      {story.is_hidden && <span className="text-amber-600 font-medium">Đang ẩn</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => toggleStoryVisibility(story)}
                      className="p-2 rounded-lg hover:bg-gray-50 text-gray-500 hover:text-gray-700 transition-colors"
                      title={story.is_hidden ? 'Hiển thị' : 'Ẩn'}
                    >
                      {story.is_hidden ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                    <button
                      onClick={() => { setEditingStory(story); setShowStoryForm(true); }}
                      className="p-2 rounded-lg hover:bg-gray-50 text-gray-500 hover:text-brand-600 transition-colors"
                      title="Sửa"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => deleteStory(story)}
                      className="p-2 rounded-lg hover:bg-red-50 text-gray-500 hover:text-red-600 transition-colors"
                      title="Xóa"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'chapters' && (
        <div>
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <select
              value={selectedStoryId}
              onChange={(e) => {
                setSelectedStoryId(e.target.value);
                if (e.target.value) fetchChapters(e.target.value);
                else setChapters([]);
              }}
              className="flex-1 text-sm rounded-lg border border-gray-200 px-3 py-2.5 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none bg-white"
            >
              <option value="">-- Chọn truyện --</option>
              {stories.map((s) => (
                <option key={s.id} value={s.id}>{s.title}</option>
              ))}
            </select>
            {selectedStoryId && (
              <button
                onClick={() => { setEditingChapter(null); setShowChapterForm(true); }}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors shrink-0"
              >
                <Plus className="h-4 w-4" /> Thêm chương
              </button>
            )}
          </div>

          {!selectedStoryId ? (
            <EmptyState icon={FileText} title="Chọn một truyện" description="Chọn truyện từ danh sách để quản lý chương." />
          ) : chapters.length === 0 ? (
            <EmptyState icon={FileText} title="Chưa có chương nào" />
          ) : (
            <div className="space-y-2">
              {chapters.map((ch) => (
                <div
                  key={ch.id}
                  className="flex items-center gap-3 bg-white rounded-xl border border-gray-100 p-4 hover:border-gray-200 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm truncate">
                      Ch.{ch.chapter_order}: {ch.title}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-gray-400 mt-0.5">
                      <span className={`px-1.5 py-0.5 rounded ${ch.status === 'published' ? 'bg-brand-50 text-brand-700' : 'bg-gray-100 text-gray-500'}`}>
                        {CHAPTER_STATUS_LABELS[ch.status]}
                      </span>
                      <span>{ch.word_count} từ</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => toggleChapterStatus(ch)}
                      className="p-2 rounded-lg hover:bg-gray-50 text-gray-500 hover:text-brand-600 transition-colors"
                      title={ch.status === 'published' ? 'Chuyển về nháp' : 'Xuất bản'}
                    >
                      {ch.status === 'published' ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                    <button
                      onClick={() => { setEditingChapter(ch); setShowChapterForm(true); }}
                      className="p-2 rounded-lg hover:bg-gray-50 text-gray-500 hover:text-brand-600 transition-colors"
                      title="Sửa"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => deleteChapter(ch)}
                      className="p-2 rounded-lg hover:bg-red-50 text-gray-500 hover:text-red-600 transition-colors"
                      title="Xóa"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {showStoryForm && (
        <StoryForm
          story={editingStory}
          genres={genres}
          onClose={() => setShowStoryForm(false)}
          onSaved={() => { setShowStoryForm(false); fetchData(); }}
        />
      )}

      {showChapterForm && selectedStoryId && (
        <ChapterEditor
          chapter={editingChapter}
          storyId={selectedStoryId}
          nextOrder={chapters.length + 1}
          onClose={() => setShowChapterForm(false)}
          onSaved={() => { setShowChapterForm(false); fetchChapters(selectedStoryId); }}
        />
      )}
    </div>
  );
}

// --- Story Form Modal ---
function StoryForm({
  story,
  genres,
  onClose,
  onSaved,
}: {
  story: Story | null;
  genres: Genre[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [title, setTitle] = useState(story?.title ?? '');
  const [author, setAuthor] = useState(story?.author ?? 'Khuyết danh');
  const [description, setDescription] = useState(story?.description ?? '');
  const [coverUrl, setCoverUrl] = useState(story?.cover_url ?? '');
  const [status, setStatus] = useState<Story['status']>(story?.status ?? 'ongoing');
  const [isHidden, setIsHidden] = useState(story?.is_hidden ?? false);
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (story) {
      supabase
        .from('story_genres')
        .select('genre_id')
        .eq('story_id', story.id)
        .then(({ data }) => {
          if (data) setSelectedGenres(data.map((sg: any) => sg.genre_id));
        });
    }
  }, [story]);

  const toggleGenre = (id: string) => {
    setSelectedGenres((prev) => prev.includes(id) ? prev.filter((g) => g !== id) : [...prev, id]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);

    try {
      const slug = slugify(title);
      if (!slug) { setError('Tiêu đề không hợp lệ'); setSaving(false); return; }

      const payload = { title, slug, author, description: description || null, cover_url: coverUrl || null, status, is_hidden: isHidden };

      let storyId = story?.id;

      if (story) {
        const { error: err } = await supabase.from('stories').update(payload).eq('id', story.id);
        if (err) throw err;
      } else {
        const { data, error: err } = await supabase.from('stories').insert(payload).select('id').single();
        if (err) throw err;
        storyId = data.id;
      }

      if (storyId) {
        await supabase.from('story_genres').delete().eq('story_id', storyId);
        if (selectedGenres.length > 0) {
          await supabase
            .from('story_genres')
            .insert(selectedGenres.map((genre_id) => ({ story_id: storyId, genre_id })));
        }
      }

      showToast('success', story ? 'Đã cập nhật truyện' : 'Đã thêm truyện mới');
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Lỗi khi lưu');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title={story ? 'Sửa truyện' : 'Thêm truyện'} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">{error}</div>}

        <Field label="Tiêu đề">
          <input type="text" required value={title} onChange={(e) => setTitle(e.target.value)} className={inputClass} />
        </Field>

        <Field label="Tác giả">
          <input type="text" value={author} onChange={(e) => setAuthor(e.target.value)} className={inputClass} />
        </Field>

        <Field label="URL ảnh bìa">
          <input type="url" value={coverUrl} onChange={(e) => setCoverUrl(e.target.value)} placeholder="https://..." className={inputClass} />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Trạng thái">
            <select value={status} onChange={(e) => setStatus(e.target.value as Story['status'])} className={inputClass}>
              <option value="ongoing">Đang ra</option>
              <option value="completed">Hoàn thành</option>
              <option value="hiatus">Tạm dừng</option>
            </select>
          </Field>

          <Field label="Hiển thị">
            <label className="flex items-center gap-2 mt-2">
              <input type="checkbox" checked={!isHidden} onChange={(e) => setIsHidden(!e.target.checked)} className="rounded" />
              <span className="text-sm text-gray-700">Hiện trên website</span>
            </label>
          </Field>
        </div>

        <Field label="Mô tả">
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} className={`${inputClass} resize-y`} />
        </Field>

        <Field label="Thể loại">
          <div className="flex flex-wrap gap-2">
            {genres.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => toggleGenre(g.id)}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                  selectedGenres.includes(g.id) ? 'bg-brand-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {g.name}
              </button>
            ))}
          </div>
        </Field>

        <FormButtons saving={saving} onCancel={onClose} submitLabel={story ? 'Lưu thay đổi' : 'Thêm truyện'} />
      </form>
    </Modal>
  );
}

// --- Shared UI helpers ---
const inputClass = 'w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none transition-all text-sm bg-white';

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-[80] flex items-start justify-center overflow-y-auto bg-black/40 p-4 sm:p-8">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl my-8">
        <div className="flex items-center justify-between border-b border-gray-100 px-6 py-4">
          <h2 className="font-bold text-gray-900">{title}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500 transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="px-6 py-5">{children}</div>
      </div>
    </div>
  );
}

function FormButtons({ saving, onCancel, submitLabel }: { saving: boolean; onCancel: () => void; submitLabel: string }) {
  return (
    <div className="flex justify-end gap-3 pt-2">
      <button type="button" onClick={onCancel} className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">
        Hủy
      </button>
      <button type="submit" disabled={saving} className="px-4 py-2 rounded-lg bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 disabled:opacity-50 transition-colors">
        {saving ? 'Đang lưu...' : submitLabel}
      </button>
    </div>
  );
}
