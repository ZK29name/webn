import { Link } from 'react-router-dom';
import { BookOpen } from 'lucide-react';

export default function NotFoundPage() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
      <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-6">
        <BookOpen className="h-10 w-10 text-gray-300" />
      </div>
      <h1 className="text-3xl font-bold text-gray-900 mb-2">404</h1>
      <p className="text-gray-500 mb-6">Trang bạn tìm không tồn tại hoặc đã bị di chuyển.</p>
      <Link
        to="/"
        className="px-6 py-2.5 rounded-lg bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors"
      >
        Về trang chủ
      </Link>
    </div>
  );
}
