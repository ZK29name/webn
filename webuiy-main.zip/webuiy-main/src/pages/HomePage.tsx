import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Clock, Sparkles, CheckCircle2, ChevronRight, BookOpen, Search } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Story } from '@/lib/types';
import StoryCard from '@/components/StoryCard';
import { Loader, ErrorState, EmptyState } from '@/components/Feedback';

export default function HomePage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [recent, setRecent] = useState<Story[]>([]);
  const [newStories, setNewStories] = useState<Story[]>([]);
  const [completed, setCompleted] = useState<Story[]>([]);

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);

        const [recentRes, newRes, completedRes] = await Promise.all([
          supabase
            .from('stories')
            .select('*')
            .eq('is_hidden', false)
            .order('updated_at', { ascending: false })
            .limit(12),
          supabase
            .from('stories')
            .select('*')
            .eq('is_hidden', false)
            .order('created_at', { ascending: false })
            .limit(6),
          supabase
            .from('stories')
            .select('*')
            .eq('is_hidden', false)
            .eq('status', 'completed')
            .order('updated_at', { ascending: false })
            .limit(6),
        ]);

        if (recentRes.error) throw recentRes.error;

        setRecent(recentRes.data as Story[]);
        setNewStories(newRes.data as Story[]);
        setCompleted(completedRes.data as Story[]);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Không thể tải dữ liệu');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) return <Loader />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="space-y-12">
      {/* Hero */}
      <section className="relative bg-gradient-to-br from-brand-50 via-white to-blue-50 overflow-hidden">
        <div className="absolute inset-0 opacity-5" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, #10b981 0, transparent 50%), radial-gradient(circle at 80% 80%, #3b82f6 0, transparent 40%)'
        }} />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-20 text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 animate-slide-up">
            Đọc truyện tiếng Việt
            <span className="block text-brand-600 mt-1">mọi lúc, mọi nơi</span>
          </h1>
          <p className="text-gray-500 max-w-2xl mx-auto text-base sm:text-lg mb-8 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Khám phá hàng ngàn tác phẩm thuộc nhiều thể loại. Trải nghiệm đọc
            thoải mái với chế độ sáng/tối và cỡ chữ tùy chỉnh.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <Link
              to="/truyen"
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 transition-colors shadow-sm"
            >
              <BookOpen className="h-5 w-5" />
              Bắt đầu đọc
            </Link>
            <Link
              to="/the-loai"
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-gray-700 text-sm font-semibold border border-gray-200 hover:border-brand-300 hover:text-brand-600 transition-colors"
            >
              <Search className="h-5 w-5" />
              Duyệt theo thể loại
            </Link>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-12">
        {recent.length === 0 && newStories.length === 0 ? (
          <EmptyState
            icon={Sparkles}
            title="Chưa có truyện nào"
            description="Hãy quay lại sau, chúng tôi đang cập nhật nội dung."
          />
        ) : (
          <>
            <Section
              title="Mới cập nhật"
              icon={Clock}
              iconColor="text-brand-600"
              stories={recent}
              viewAllLink="/truyen"
            />

            <Section
              title="Truyện mới đăng"
              icon={Sparkles}
              iconColor="text-blue-600"
              stories={newStories}
              viewAllLink="/truyen?sort=created"
            />

            <Section
              title="Truyện hoàn thành"
              icon={CheckCircle2}
              iconColor="text-brand-600"
              stories={completed}
              viewAllLink="/truyen?status=completed"
            />
          </>
        )}
      </div>
    </div>
  );
}

function Section({
  title,
  icon: Icon,
  iconColor,
  stories,
  viewAllLink,
}: {
  title: string;
  icon: React.ElementType;
  iconColor: string;
  stories: Story[];
  viewAllLink: string;
}) {
  if (stories.length === 0) return null;

  return (
    <section>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          <Icon className={`h-5 w-5 ${iconColor}`} />
          {title}
        </h2>
        <Link
          to={viewAllLink}
          className="text-sm text-brand-600 hover:text-brand-700 font-medium flex items-center gap-1"
        >
          Xem tất cả <ChevronRight className="h-4 w-4" />
        </Link>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
        {stories.map((story) => (
          <StoryCard key={story.id} story={story} />
        ))}
      </div>
    </section>
  );
}
