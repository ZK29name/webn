import { useEffect, useState, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, List, Sun, Moon, Type, Home as HomeIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Chapter, Story } from '@/lib/types';
import { Loader, ErrorState } from '@/components/Feedback';
import { useAuth } from '@/lib/auth';
import { readingTime } from '@/lib/utils';

const FONT_SIZES = [16, 18, 20, 22, 24];

export default function ReadChapterPage() {
  const { slug, chapterId } = useParams<{ slug: string; chapterId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [chapter, setChapter] = useState<Chapter | null>(null);
  const [story, setStory] = useState<Story | null>(null);
  const [allChapters, setAllChapters] = useState<Chapter[]>([]);
  const [showChapterList, setShowChapterList] = useState(false);

  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('read-dark') === 'true');
  const [fontSize, setFontSize] = useState(() => parseInt(localStorage.getItem('read-fontsize') ?? '18', 10));

  useEffect(() => { localStorage.setItem('read-dark', String(darkMode)); }, [darkMode]);
  useEffect(() => { localStorage.setItem('read-fontsize', String(fontSize)); }, [fontSize]);

  const fetchData = useCallback(async () => {
    if (!slug || !chapterId) return;
    setLoading(true);
    setError(null);
    try {
      const { data: storyData, error: storyErr } = await supabase
        .from('stories')
        .select('*')
        .eq('slug', slug)
        .maybeSingle();
      if (storyErr) throw storyErr;
      if (!storyData) { setError('Không tìm thấy truyện'); return; }
      const s = storyData as Story;
      setStory(s);

      const { data: chData, error: chErr } = await supabase
        .from('chapters')
        .select('*')
        .eq('id', chapterId)
        .eq('story_id', s.id)
        .eq('status', 'published')
        .maybeSingle();
      if (chErr) throw chErr;
      if (!chData) { setError('Không tìm thấy chương'); return; }
      setChapter(chData as Chapter);

      const { data: listData } = await supabase
        .from('chapters')
        .select('id, title, chapter_order, word_count, status, updated_at, created_at, story_id')
        .eq('story_id', s.id)
        .eq('status', 'published')
        .order('chapter_order', { ascending: true });
      setAllChapters((listData as Chapter[]) ?? []);

      if (user) {
        const { data: existing } = await supabase
          .from('reading_history')
          .select('id')
          .eq('user_id', user.id)
          .eq('story_id', s.id)
          .maybeSingle();

        if (existing) {
          await supabase
            .from('reading_history')
            .update({ chapter_id: chData.id, read_at: new Date().toISOString() })
            .eq('id', existing.id);
        } else {
          await supabase
            .from('reading_history')
            .insert({ user_id: user.id, story_id: s.id, chapter_id: chData.id });
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Không thể tải chương');
    } finally {
      setLoading(false);
    }
  }, [slug, chapterId, user]);

  useEffect(() => {
    fetchData();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [fetchData]);

  const currentIndex = allChapters.findIndex((c) => c.id === chapterId);
  const prevChapter = currentIndex > 0 ? allChapters[currentIndex - 1] : null;
  const nextChapter = currentIndex >= 0 && currentIndex < allChapters.length - 1 ? allChapters[currentIndex + 1] : null;

  const goChapter = (chId: string) => {
    if (story) {
      navigate(`/truyen/${story.slug}/chuong/${chId}`);
      setShowChapterList(false);
    }
  };

  if (loading) return <Loader label="Đang tải chương..." />;
  if (error) return <ErrorState message={error} />;
  if (!chapter || !story) return <ErrorState message="Không tìm thấy nội dung" />;

  const bg = darkMode ? 'bg-gray-900' : 'bg-gray-50';
  const headerBg = darkMode ? 'bg-gray-800' : 'bg-white';
  const text = darkMode ? 'text-gray-200' : 'text-gray-800';
  const muted = darkMode ? 'text-gray-400' : 'text-gray-500';
  const border = darkMode ? 'border-gray-700' : 'border-gray-100';
  const hover = darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-50';
  const listDivide = darkMode ? 'divide-gray-700' : 'divide-gray-100';

  return (
    <div className={`min-h-screen ${bg} transition-colors duration-200`}>
      {/* Reading toolbar */}
      <div className={`sticky top-0 z-40 ${headerBg} border-b ${border} backdrop-blur-sm`}>
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between gap-2">
          <Link
            to={`/truyen/${story.slug}`}
            className={`flex items-center gap-1.5 text-sm ${muted} hover:text-brand-500 transition-colors shrink-0 min-w-0`}
          >
            <ChevronLeft className="h-4 w-4 shrink-0" />
            <span className="truncate">{story.title}</span>
          </Link>

          <div className="flex items-center gap-1 shrink-0">
            <div className={`flex items-center rounded-lg border ${border} overflow-hidden`}>
              <button
                onClick={() => setFontSize((s) => Math.min(FONT_SIZES[FONT_SIZES.length - 1], s + 2))}
                className={`px-2 py-1.5 text-xs ${text} ${hover} transition-colors`}
                title="Tăng cỡ chữ"
              >
                A+
              </button>
              <span className={`px-1 text-xs ${muted}`}>{fontSize}</span>
              <button
                onClick={() => setFontSize((s) => Math.max(FONT_SIZES[0], s - 2))}
                className={`px-2 py-1.5 text-xs ${text} ${hover} transition-colors`}
                title="Giảm cỡ chữ"
              >
                A−
              </button>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2 rounded-lg ${hover} ${text} transition-colors`}
              title="Chế độ sáng/tối"
            >
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <button
              onClick={() => setShowChapterList(!showChapterList)}
              className={`p-2 rounded-lg ${hover} ${text} transition-colors`}
              title="Danh sách chương"
            >
              <List className="h-4 w-4" />
            </button>
            <Link
              to="/"
              className={`p-2 rounded-lg ${hover} ${text} transition-colors`}
              title="Trang chủ"
            >
              <HomeIcon className="h-4 w-4" />
            </Link>
          </div>
        </div>

        {showChapterList && (
          <div className={`max-w-3xl mx-auto px-4 pb-4 max-h-72 overflow-y-auto scrollbar-thin border-t ${border}`}>
            <ul className={`divide-y ${listDivide}`}>
              {allChapters.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => goChapter(c.id)}
                    className={`w-full text-left py-2.5 text-sm transition-colors ${
                      c.id === chapterId ? `font-semibold text-brand-500` : `${text} ${hover}`
                    }`}
                  >
                    {c.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Chapter content */}
      <article className="max-w-3xl mx-auto px-4 sm:px-6 py-8 sm:py-10 animate-fade-in">
        <h1 className={`text-xl sm:text-2xl font-bold mb-2 ${text}`}>{chapter.title}</h1>
        <p className={`text-sm ${muted} mb-8`}>{readingTime(chapter.word_count)}</p>

        <div
          className={`${text} whitespace-pre-line`}
          style={{ fontSize: `${fontSize}px`, lineHeight: 1.85 }}
        >
          {chapter.content}
        </div>
      </article>

      {/* Navigation */}
      <div className={`max-w-3xl mx-auto px-4 sm:px-6 py-6 border-t ${border}`}>
        <div className="flex items-center justify-between gap-3">
          <button
            onClick={() => prevChapter && goChapter(prevChapter.id)}
            disabled={!prevChapter}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border ${border} ${text} text-sm font-medium disabled:opacity-30 ${hover} transition-colors`}
          >
            <ChevronLeft className="h-4 w-4" />
            <span className="hidden sm:inline">Chương trước</span>
            <span className="sm:hidden">Trước</span>
          </button>

          <Link
            to={`/truyen/${story.slug}`}
            className={`px-4 py-2.5 rounded-lg border ${border} ${text} text-sm font-medium ${hover} transition-colors hidden sm:block`}
          >
            Về truyện
          </Link>

          <button
            onClick={() => nextChapter && goChapter(nextChapter.id)}
            disabled={!nextChapter}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border ${border} ${text} text-sm font-medium disabled:opacity-30 ${hover} transition-colors`}
          >
            <span className="hidden sm:inline">Chương sau</span>
            <span className="sm:hidden">Sau</span>
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>

        {!nextChapter && (
          <p className={`text-center text-sm ${muted} mt-4`}>
            Bạn đã đọc đến chương mới nhất của truyện này.
          </p>
        )}
      </div>
    </div>
  );
}
