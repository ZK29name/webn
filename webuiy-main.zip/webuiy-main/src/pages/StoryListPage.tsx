import { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Filter, BookX } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Story, Genre } from '@/lib/types';
import StoryCard from '@/components/StoryCard';
import { Loader, ErrorState, EmptyState } from '@/components/Feedback';

const PER_PAGE = 12;

export default function StoryListPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stories, setStories] = useState<Story[]>([]);
  const [genres, setGenres] = useState<Genre[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);

  const q = searchParams.get('q') ?? '';
  const genre = searchParams.get('genre') ?? '';
  const status = searchParams.get('status') ?? '';
  const sort = searchParams.get('sort') ?? 'updated';

  const [searchInput, setSearchInput] = useState(q);

  useEffect(() => {
    setSearchInput(q);
  }, [q]);

  useEffect(() => {
    supabase.from('genres').select('*').order('name').then(({ data }) => {
      setGenres(data as Genre[]);
    });
  }, []);

  const fetchStories = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let query = supabase
        .from('stories')
        .select('*', { count: 'exact' })
        .eq('is_hidden', false);

      if (q) {
        query = query.or(`title.ilike.%${q}%,author.ilike.%${q}%`);
      }
      if (status) {
        query = query.eq('status', status);
      }
      if (genre) {
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        if (uuidRegex.test(genre)) {
          query = query.filter('id', 'in', `(SELECT story_id FROM story_genres WHERE genre_id = '${genre}')`);
        }
      }

      const orderCol = sort === 'created' ? 'created_at' : 'updated_at';
      query = query.order(orderCol, { ascending: false });

      const from = (page - 1) * PER_PAGE;
      query = query.range(from, from + PER_PAGE - 1);

      const { data, error: err, count } = await query;
      if (err) throw err;

      setStories(data as Story[]);
      setTotal(count ?? 0);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Không thể tải danh sách truyện');
    } finally {
      setLoading(false);
    }
  }, [q, genre, status, sort, page]);

  useEffect(() => {
    fetchStories();
  }, [fetchStories]);

  const updateParam = (key: string, value: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) {
      newParams.set(key, value);
    } else {
      newParams.delete(key);
    }
    setPage(1);
    setSearchParams(newParams);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    updateParam('q', searchInput.trim());
  };

  const totalPages = Math.ceil(total / PER_PAGE);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Danh sách truyện</h1>

      <div className="bg-white rounded-xl border border-gray-100 p-4 mb-6">
        <form onSubmit={handleSearch} className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Tìm theo tên truyện hoặc tác giả..."
              className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none transition-colors"
            />
          </div>
        </form>

        <div className="flex flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={genre}
              onChange={(e) => updateParam('genre', e.target.value)}
              className="text-sm rounded-lg border border-gray-200 px-3 py-1.5 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none bg-white"
            >
              <option value="">Tất cả thể loại</option>
              {genres.map((g) => (
                <option key={g.id} value={g.id}>{g.name}</option>
              ))}
            </select>
          </div>

          <select
            value={status}
            onChange={(e) => updateParam('status', e.target.value)}
            className="text-sm rounded-lg border border-gray-200 px-3 py-1.5 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none bg-white"
          >
            <option value="">Tất cả trạng thái</option>
            <option value="ongoing">Đang ra</option>
            <option value="completed">Hoàn thành</option>
            <option value="hiatus">Tạm dừng</option>
          </select>

          <select
            value={sort}
            onChange={(e) => updateParam('sort', e.target.value)}
            className="text-sm rounded-lg border border-gray-200 px-3 py-1.5 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none bg-white"
          >
            <option value="updated">Mới cập nhật</option>
            <option value="created">Mới đăng</option>
          </select>

          {(q || genre || status) && (
            <button
              onClick={() => {
                setSearchInput('');
                setSearchParams(new URLSearchParams());
                setPage(1);
              }}
              className="text-sm text-gray-500 hover:text-red-600 transition-colors"
            >
              Xóa bộ lọc
            </button>
          )}
        </div>
      </div>

      <p className="text-sm text-gray-500 mb-4">{total} truyện</p>

      {loading ? (
        <Loader />
      ) : error ? (
        <ErrorState message={error} onRetry={fetchStories} />
      ) : stories.length === 0 ? (
        <EmptyState
          icon={BookX}
          title="Không tìm thấy truyện"
          description="Thử thay đổi từ khóa hoặc bộ lọc để tìm thêm truyện."
        />
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {stories.map((story) => (
              <StoryCard key={story.id} story={story} />
            ))}
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-8">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-3 py-2 rounded-lg border border-gray-200 text-sm disabled:opacity-40 hover:bg-gray-50 transition-colors"
              >
                Trước
              </button>
              <span className="text-sm text-gray-600">
                Trang {page} / {totalPages}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="px-3 py-2 rounded-lg border border-gray-200 text-sm disabled:opacity-40 hover:bg-gray-50 transition-colors"
              >
                Sau
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
