import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Tag, ChevronRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Genre } from '@/lib/types';
import { Loader, ErrorState, EmptyState } from '@/components/Feedback';

interface GenreWithCount extends Genre {
  story_count: number;
}

export default function GenresPage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [genres, setGenres] = useState<GenreWithCount[]>([]);

  useEffect(() => {
    async function load() {
      try {
        const { data, error: err } = await supabase
          .from('genres')
          .select('id, name, slug, description')
          .order('name');

        if (err) throw err;

        const genreList = data as Genre[];
        const withCounts: GenreWithCount[] = await Promise.all(
          genreList.map(async (g) => {
            const { count } = await supabase
              .from('story_genres')
              .select('story_id', { count: 'exact', head: true })
              .eq('genre_id', g.id);
            return { ...g, story_count: count ?? 0 };
          })
        );
        setGenres(withCounts);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Không thể tải thể loại');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) return <Loader />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Thể loại</h1>
        <p className="text-gray-500">Khám phá truyện theo thể loại bạn yêu thích</p>
      </div>

      {genres.length === 0 ? (
        <EmptyState icon={Tag} title="Chưa có thể loại nào" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {genres.map((g) => (
            <Link
              key={g.id}
              to={`/truyen?genre=${g.id}`}
              className="group flex items-center justify-between bg-white rounded-xl border border-gray-100 p-5 hover:border-brand-200 hover:shadow-md transition-all duration-200"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Tag className="h-4 w-4 text-brand-500" />
                  <h3 className="font-semibold text-gray-900 group-hover:text-brand-600 transition-colors">
                    {g.name}
                  </h3>
                </div>
                {g.description && (
                  <p className="text-sm text-gray-500 line-clamp-2">{g.description}</p>
                )}
                <p className="text-xs text-gray-400 mt-2">{g.story_count} truyện</p>
              </div>
              <ChevronRight className="h-5 w-5 text-gray-300 group-hover:text-brand-500 group-hover:translate-x-1 transition-all shrink-0" />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
