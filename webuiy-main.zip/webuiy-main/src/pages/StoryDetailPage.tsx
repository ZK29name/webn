import { useEffect, useState, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { BookOpen, Bookmark, BookmarkCheck, User, Calendar, ChevronRight, List } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Story, Genre, Chapter } from '@/lib/types';
import { STORY_STATUS_LABELS, STORY_STATUS_COLORS } from '@/lib/types';
import { Loader, ErrorState, EmptyState } from '@/components/Feedback';
import { useAuth } from '@/lib/auth';
import { showToast } from '@/components/Toast';
import { formatDate, formatRelativeTime, readingTime } from '@/lib/utils';

export default function StoryDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [story, setStory] = useState<Story | null>(null);
  const [genres, setGenres] = useState<Genre[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [chapterSortAsc, setChapterSortAsc] = useState(true);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [bookmarkLoading, setBookmarkLoading] = useState(false);
  const { user } = useAuth();

  const fetchData = useCallback(async () => {
    if (!slug) return;
    setLoading(true);
    setError(null);
    try {
      const { data: storyData, error: storyErr } = await supabase
        .from('stories')
        .select('*')
        .eq('slug', slug)
        .maybeSingle();

      if (storyErr) throw storyErr;
      if (!storyData) {
        setError('Không tìm thấy truyện');
        return;
      }

      const s = storyData as Story;
      setStory(s);

      const [genresRes, chaptersRes] = await Promise.all([
        supabase
          .from('story_genres')
          .select('genres(id, name, slug)')
          .eq('story_id', s.id),
        supabase
          .from('chapters')
          .select('id, title, chapter_order, word_count, status, updated_at')
          .eq('story_id', s.id)
          .eq('status', 'published')
          .order('chapter_order', { ascending: true }),
      ]);

      if (genresRes.error) throw genresRes.error;
      if (chaptersRes.error) throw chaptersRes.error;

      setGenres(genresRes.data.map((sg: any) => sg.genres as Genre));
      setChapters(chaptersRes.data as Chapter[]);

      if (user) {
        const { data: bm } = await supabase
          .from('bookmarks')
          .select('story_id')
          .eq('story_id', s.id)
          .eq('user_id', user.id)
          .maybeSingle();
        setIsBookmarked(!!bm);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Không thể tải truyện');
    } finally {
      setLoading(false);
    }
  }, [slug, user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const toggleBookmark = async () => {
    if (!user) {
      showToast('info', 'Vui lòng đăng nhập để lưu truyện vào thư viện');
      return;
    }
    if (!story) return;

    setBookmarkLoading(true);
    try {
      if (isBookmarked) {
        const { error: delErr } = await supabase
          .from('bookmarks')
          .delete()
          .eq('story_id', story.id)
          .eq('user_id', user.id);
        if (delErr) throw delErr;
        setIsBookmarked(false);
        showToast('success', 'Đã xóa khỏi thư viện');
      } else {
        const { error: insErr } = await supabase
          .from('bookmarks')
          .insert({ story_id: story.id, user_id: user.id });
        if (insErr) throw insErr;
        setIsBookmarked(true);
        showToast('success', 'Đã thêm vào thư viện');
      }
    } catch {
      showToast('error', 'Không thể cập nhật thư viện');
    } finally {
      setBookmarkLoading(false);
    }
  };

  if (loading) return <Loader />;
  if (error) return <ErrorState message={error} />;
  if (!story) return <ErrorState message="Không tìm thấy truyện" />;

  const sortedChapters = chapterSortAsc ? chapters : [...chapters].reverse();

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      <nav className="text-sm text-gray-500 mb-6 flex items-center gap-1.5 flex-wrap">
        <Link to="/" className="hover:text-brand-600 transition-colors">Trang chủ</Link>
        <ChevronRight className="h-4 w-4 shrink-0" />
        <Link to="/truyen" className="hover:text-brand-600 transition-colors">Truyện</Link>
        <ChevronRight className="h-4 w-4 shrink-0" />
        <span className="text-gray-700 truncate">{story.title}</span>
      </nav>

      {/* Story header */}
      <div className="flex flex-col sm:flex-row gap-6 mb-8">
        <div className="shrink-0 mx-auto sm:mx-0">
          <div className="w-44 h-60 sm:w-48 sm:h-64 rounded-xl overflow-hidden bg-gradient-to-br from-gray-50 to-gray-100 shadow-md ring-1 ring-gray-100">
            {story.cover_url ? (
              <img src={story.cover_url} alt={story.title} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-gray-300">
                <BookOpen className="h-16 w-16" />
              </div>
            )}
          </div>
        </div>

        <div className="flex-1 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row sm:items-start gap-2 sm:gap-3 mb-3">
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 flex-1 leading-tight">{story.title}</h1>
            <span className={`px-3 py-1 rounded-full text-sm font-medium shrink-0 self-center ${STORY_STATUS_COLORS[story.status]}`}>
              {STORY_STATUS_LABELS[story.status]}
            </span>
          </div>

          <div className="flex items-center justify-center sm:justify-start gap-4 text-sm text-gray-500 mb-4">
            <span className="flex items-center gap-1.5">
              <User className="h-4 w-4" /> {story.author}
            </span>
            <span className="flex items-center gap-1.5">
              <Calendar className="h-4 w-4" /> {formatDate(story.created_at)}
            </span>
          </div>

          {genres.length > 0 && (
            <div className="flex flex-wrap justify-center sm:justify-start gap-2 mb-4">
              {genres.map((g) => (
                <Link
                  key={g.id}
                  to={`/truyen?genre=${g.id}`}
                  className="px-3 py-1 rounded-full bg-brand-50 text-brand-700 text-sm font-medium hover:bg-brand-100 transition-colors"
                >
                  {g.name}
                </Link>
              ))}
            </div>
          )}

          <div className="flex items-center justify-center sm:justify-start gap-3 flex-wrap">
            <button
              onClick={toggleBookmark}
              disabled={bookmarkLoading}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isBookmarked
                  ? 'bg-brand-50 text-brand-700 hover:bg-brand-100'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {isBookmarked ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
              {isBookmarked ? 'Đã lưu' : 'Lưu vào thư viện'}
            </button>

            {chapters.length > 0 && (
              <Link
                to={`/truyen/${story.slug}/chuong/${chapters[0].id}`}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors"
              >
                <BookOpen className="h-4 w-4" /> Đọc từ đầu
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Description */}
      {story.description && (
        <div className="bg-white rounded-xl border border-gray-100 p-5 sm:p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Giới thiệu</h2>
          <p className="text-gray-600 leading-relaxed whitespace-pre-line text-[15px]">{story.description}</p>
        </div>
      )}

      {/* Chapter list */}
      <div className="bg-white rounded-xl border border-gray-100 p-5 sm:p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <List className="h-5 w-5 text-gray-400" />
            Danh sách chương
            <span className="text-sm font-normal text-gray-400">({chapters.length} chương)</span>
          </h2>
          {chapters.length > 1 && (
            <button
              onClick={() => setChapterSortAsc(!chapterSortAsc)}
              className="text-sm text-gray-500 hover:text-brand-600 font-medium transition-colors"
            >
              {chapterSortAsc ? 'Mới nhất trước' : 'Cũ nhất trước'}
            </button>
          )}
        </div>

        {chapters.length === 0 ? (
          <EmptyState
            icon={BookOpen}
            title="Chưa có chương nào"
            description="Truyện này chưa có chương được xuất bản."
          />
        ) : (
          <div className="divide-y divide-gray-50 max-h-[500px] overflow-y-auto scrollbar-thin -mr-2 pr-2">
            {sortedChapters.map((ch) => (
              <Link
                key={ch.id}
                to={`/truyen/${story.slug}/chuong/${ch.id}`}
                className="flex items-center justify-between py-3 px-2 hover:bg-gray-50 rounded-lg transition-colors group"
              >
                <span className="text-sm text-gray-700 group-hover:text-brand-600 transition-colors truncate mr-3">
                  {ch.title}
                </span>
                <div className="flex items-center gap-3 text-xs text-gray-400 shrink-0">
                  <span className="hidden sm:inline">{readingTime(ch.word_count)}</span>
                  <span>{formatRelativeTime(ch.updated_at)}</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
