import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bookmark, History, BookOpen, Trash2, ChevronRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import type { Story, Chapter } from '@/lib/types';
import { STORY_STATUS_LABELS, STORY_STATUS_COLORS } from '@/lib/types';
import StoryCard from '@/components/StoryCard';
import { Loader, EmptyState } from '@/components/Feedback';
import { showToast } from '@/components/Toast';
import { formatRelativeTime, readingTime } from '@/lib/utils';

interface HistoryRow {
  id: string;
  read_at: string;
  stories: Story | null;
  chapters: { id: string; title: string; chapter_order: number; word_count: number } | null;
}

export default function LibraryPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState<'bookmarks' | 'history'>('bookmarks');
  const [loading, setLoading] = useState(true);
  const [bookmarks, setBookmarks] = useState<Story[]>([]);
  const [history, setHistory] = useState<HistoryRow[]>([]);

  useEffect(() => {
    if (!user) return;
    async function load() {
      setLoading(true);
      try {
        const [bmRes, histRes] = await Promise.all([
          supabase
            .from('bookmarks')
            .select('stories(*)')
            .eq('user_id', user!.id)
            .order('created_at', { ascending: false }),
          supabase
            .from('reading_history')
            .select('id, read_at, stories(id, title, slug, author, description, cover_url, status, is_hidden, created_at, updated_at), chapters(id, title, chapter_order, word_count)')
            .eq('user_id', user!.id)
            .order('read_at', { ascending: false })
            .limit(20),
        ]);

        if (bmRes.data) {
          setBookmarks(bmRes.data.map((b: any) => b.stories as Story).filter(Boolean));
        }
        if (histRes.data) {
          setHistory((histRes.data as unknown as HistoryRow[]).filter((h) => h.stories && h.chapters));
        }
      } catch {
        showToast('error', 'Không thể tải thư viện');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [user]);

  const removeBookmark = async (storyId: string) => {
    if (!user) return;
    const { error } = await supabase
      .from('bookmarks')
      .delete()
      .eq('user_id', user.id)
      .eq('story_id', storyId);
    if (error) {
      showToast('error', 'Không thể xóa');
      return;
    }
    setBookmarks((prev) => prev.filter((s) => s.id !== storyId));
    showToast('success', 'Đã xóa khỏi thư viện');
  };

  const clearHistory = async () => {
    if (!user) return;
    const { error } = await supabase
      .from('reading_history')
      .delete()
      .eq('user_id', user.id);
    if (error) {
      showToast('error', 'Không thể xóa lịch sử');
      return;
    }
    setHistory([]);
    showToast('success', 'Đã xóa lịch sử đọc');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-6">Thư viện cá nhân</h1>

      <div className="flex items-center gap-1 border-b border-gray-200 mb-6">
        <button
          onClick={() => setTab('bookmarks')}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
            tab === 'bookmarks'
              ? 'border-brand-600 text-brand-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <Bookmark className="h-4 w-4" />
          Truyện yêu thích
          {bookmarks.length > 0 && (
            <span className="text-xs bg-gray-100 px-1.5 py-0.5 rounded-full">{bookmarks.length}</span>
          )}
        </button>
        <button
          onClick={() => setTab('history')}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
            tab === 'history'
              ? 'border-brand-600 text-brand-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <History className="h-4 w-4" />
          Lịch sử đọc
          {history.length > 0 && (
            <span className="text-xs bg-gray-100 px-1.5 py-0.5 rounded-full">{history.length}</span>
          )}
        </button>
      </div>

      {loading ? (
        <Loader />
      ) : tab === 'bookmarks' ? (
        bookmarks.length === 0 ? (
          <EmptyState
            icon={Bookmark}
            title="Chưa có truyện yêu thích"
            description="Lưu truyện bạn thích để tìm lại nhanh chóng tại đây."
            action={
              <Link to="/truyen" className="text-brand-600 hover:text-brand-700 font-medium text-sm">
                Khám phá truyện
              </Link>
            }
          />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {bookmarks.map((story) => (
              <div key={story.id} className="relative group">
                <StoryCard story={story} />
                <button
                  onClick={() => removeBookmark(story.id)}
                  className="absolute top-2 right-2 p-1.5 rounded-lg bg-white/90 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-50 hover:text-red-600"
                  title="Xóa khỏi thư viện"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )
      ) : history.length === 0 ? (
        <EmptyState
          icon={History}
          title="Chưa có lịch sử đọc"
          description="Lịch sử đọc sẽ xuất hiện tại đây sau khi bạn đọc truyện."
          action={
            <Link to="/truyen" className="text-brand-600 hover:text-brand-700 font-medium text-sm">
              Bắt đầu đọc
            </Link>
          }
        />
      ) : (
        <div className="space-y-3">
          <div className="flex justify-end mb-2">
            <button
              onClick={clearHistory}
              className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-red-600 transition-colors"
            >
              <Trash2 className="h-4 w-4" /> Xóa tất cả
            </button>
          </div>
          {history.map((h) => {
            const story = h.stories;
            const chapter = h.chapters;
            if (!story || !chapter) return null;
            return (
              <Link
                key={h.id}
                to={`/truyen/${story.slug}/chuong/${chapter.id}`}
                className="flex items-center gap-4 bg-white rounded-xl border border-gray-100 p-4 hover:border-brand-200 hover:shadow-sm transition-all group"
              >
                <div className="w-12 h-16 rounded-lg overflow-hidden bg-gray-100 shrink-0">
                  {story.cover_url ? (
                    <img src={story.cover_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <BookOpen className="h-5 w-5 text-gray-300" />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 text-sm group-hover:text-brand-600 transition-colors truncate">
                    {story.title}
                  </h3>
                  <p className="text-sm text-gray-500 truncate">{chapter.title}</p>
                  <div className="flex items-center gap-3 text-xs text-gray-400 mt-1">
                    <span>{readingTime(chapter.word_count)}</span>
                    <span>·</span>
                    <span>{formatRelativeTime(h.read_at)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${STORY_STATUS_COLORS[story.status]}`}>
                    {STORY_STATUS_LABELS[story.status]}
                  </span>
                  <ChevronRight className="h-5 w-5 text-gray-300 group-hover:text-brand-500 transition-colors" />
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
