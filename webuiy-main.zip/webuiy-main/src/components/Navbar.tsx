import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { BookOpen, Search, Menu, X, Bookmark, LogOut, Shield, User as UserIcon } from 'lucide-react';
import { useAuth } from '@/lib/auth';

export default function Navbar() {
  const { user, profile, isAdmin, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/truyen?q=${encodeURIComponent(searchQuery.trim())}`);
      setMobileOpen(false);
    }
  };

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `text-sm font-medium transition-colors ${
      isActive ? 'text-brand-600' : 'text-gray-600 hover:text-brand-600'
    }`;

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex h-16 items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <BookOpen className="h-7 w-7 text-brand-600" />
            <span className="text-lg font-bold text-gray-900 hidden sm:inline">Truyện Việt</span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <NavLink to="/" end className={navLinkClass}>Trang chủ</NavLink>
            <NavLink to="/truyen" className={navLinkClass}>Truyện</NavLink>
            <NavLink to="/the-loai" className={navLinkClass}>Thể loại</NavLink>
            {user && <NavLink to="/thu-vien" className={navLinkClass}>Thư viện</NavLink>}
          </nav>

          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xs">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm truyện..."
                className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-gray-200 focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none transition-colors"
              />
            </div>
          </form>

          <div className="hidden md:flex items-center gap-3 shrink-0">
            {user ? (
              <>
                {isAdmin && (
                  <Link
                    to="/admin"
                    className="flex items-center gap-1.5 text-sm font-medium text-gray-600 hover:text-brand-600 transition-colors"
                  >
                    <Shield className="h-4 w-4" />
                    Quản trị
                  </Link>
                )}
                <Link
                  to="/thu-vien"
                  className="flex items-center gap-1.5 text-sm font-medium text-gray-600 hover:text-brand-600 transition-colors"
                >
                  <Bookmark className="h-4 w-4" />
                  {profile?.username}
                </Link>
                <button
                  onClick={() => signOut()}
                  className="flex items-center gap-1.5 text-sm font-medium text-gray-600 hover:text-red-600 transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  Đăng xuất
                </button>
              </>
            ) : (
              <>
                <Link to="/dang-nhap" className="text-sm font-medium text-gray-600 hover:text-brand-600 transition-colors">
                  Đăng nhập
                </Link>
                <Link
                  to="/dang-ky"
                  className="text-sm font-medium text-white bg-brand-600 hover:bg-brand-700 px-4 py-2 rounded-lg transition-colors"
                >
                  Đăng ký
                </Link>
              </>
            )}
          </div>

          <button
            className="md:hidden p-2 text-gray-600"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Menu"
          >
            {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-gray-100 bg-white">
          <div className="px-4 py-4 space-y-3">
            <form onSubmit={handleSearch}>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Tìm truyện..."
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-gray-200 focus:border-brand-400 focus:ring-1 focus:ring-brand-400 outline-none"
                />
              </div>
            </form>
            <nav className="flex flex-col gap-1" onClick={() => setMobileOpen(false)}>
              <NavLink to="/" end className="py-2 px-3 rounded-lg hover:bg-gray-50 text-gray-700 font-medium">Trang chủ</NavLink>
              <NavLink to="/truyen" className="py-2 px-3 rounded-lg hover:bg-gray-50 text-gray-700 font-medium">Truyện</NavLink>
              <NavLink to="/the-loai" className="py-2 px-3 rounded-lg hover:bg-gray-50 text-gray-700 font-medium">Thể loại</NavLink>
              {user && <NavLink to="/thu-vien" className="py-2 px-3 rounded-lg hover:bg-gray-50 text-gray-700 font-medium">Thư viện</NavLink>}
              {isAdmin && <NavLink to="/admin" className="py-2 px-3 rounded-lg hover:bg-gray-50 text-gray-700 font-medium">Quản trị</NavLink>}
            </nav>
            <div className="border-t pt-3" onClick={() => setMobileOpen(false)}>
              {user ? (
                <button
                  onClick={() => signOut()}
                  className="w-full flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-gray-50 text-red-600 font-medium"
                >
                  <LogOut className="h-4 w-4" /> Đăng xuất
                </button>
              ) : (
                <div className="flex flex-col gap-2">
                  <Link to="/dang-nhap" className="flex items-center gap-2 py-2 px-3 rounded-lg border border-gray-200 text-gray-700 font-medium">
                    <UserIcon className="h-4 w-4" /> Đăng nhập
                  </Link>
                  <Link to="/dang-ky" className="py-2 px-3 rounded-lg bg-brand-600 text-white text-center font-medium">
                    Đăng ký
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
