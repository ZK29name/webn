import { useState, useMemo, useEffect, useRef } from 'react';
import { Eye, Pencil, Save, Send, X, AlertCircle, FileText, Sparkles, CheckCircle2, RotateCcw } from 'lucide-react';
import type { Chapter } from '@/lib/types';
import { supabase } from '@/lib/supabase';
import { showToast } from '@/components/Toast';
import { normalizePastedText, countWords, countParagraphs, countCharacters } from '@/lib/textProcessing';
import { convertToVietnamese, isConverterAvailable, type ConverterOptions } from '@/lib/translator';

type EditorMode = 'edit' | 'preview';
type SaveAction = 'draft' | 'publish';

interface ChapterEditorProps {
  chapter: Chapter | null;
  storyId: string;
  nextOrder: number;
  onClose: () => void;
  onSaved: () => void;
}

export function ChapterEditor({ chapter, storyId, nextOrder, onClose, onSaved }: ChapterEditorProps) {
  const [title, setTitle] = useState(chapter?.title ?? '');
  const [content, setContent] = useState(chapter?.content ?? '');
  const [chapterOrder, setChapterOrder] = useState(chapter?.chapter_order ?? nextOrder);
  const [status, setStatus] = useState<Chapter['status']>(chapter?.status ?? 'draft');
  const [mode, setMode] = useState<EditorMode>('edit');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);
  const [convertStatus, setConvertStatus] = useState<'idle' | 'converting' | 'done' | 'unavailable'>('idle');
  const [convertMessage, setConvertMessage] = useState<string | null>(null);
  const [originalContent, setOriginalContent] = useState<string | null>(null);

  const textAreaRef = useRef<HTMLTextAreaElement>(null);
  const isExisting = !!chapter;

  const stats = useMemo(() => ({
    words: countWords(content),
    paragraphs: countParagraphs(content),
    characters: countCharacters(content),
  }), [content]);

  // Mark dirty when content/title changes
  useEffect(() => {
    setDirty(true);
  }, [content, title, chapterOrder]);

  // Prevent accidental navigation with unsaved changes
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (dirty && !saving) {
        e.preventDefault();
      }
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [dirty, saving]);

  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    e.preventDefault();
    const raw = e.clipboardData.getData('text/plain');
    const normalized = normalizePastedText(raw);

    const textarea = e.currentTarget;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const newContent = content.slice(0, start) + normalized + content.slice(end);

    setContent(newContent);
    setDirty(true);

    // Restore cursor position after paste
    requestAnimationFrame(() => {
      textarea.focus();
      const pos = start + normalized.length;
      textarea.setSelectionRange(pos, pos);
    });
  };

  const handleSave = async (action: SaveAction) => {
    setError(null);

    if (!title.trim()) {
      setError('Tiêu đề chương không được để trống');
      return;
    }
    if (!content.trim()) {
      setError('Nội dung chương không được để trống');
      return;
    }

    const targetStatus = action === 'publish' ? 'published' : 'draft';
    setSaving(true);

    try {
      const payload = {
        story_id: storyId,
        title: title.trim(),
        content,
        chapter_order: chapterOrder,
        status: targetStatus,
      };

      if (isExisting && chapter) {
        const { error: err } = await supabase
          .from('chapters')
          .update(payload)
          .eq('id', chapter.id);

        if (err) {
          throw new Error(formatSupabaseError(err, 'Lỗi khi cập nhật chương'));
        }
      } else {
        const { error: err } = await supabase
          .from('chapters')
          .insert(payload);

        if (err) {
          throw new Error(formatSupabaseError(err, 'Lỗi khi tạo chương'));
        }
      }

      setStatus(targetStatus);
      setDirty(false);
      showToast(
        'success',
        action === 'publish'
          ? 'Đã xuất bản chương'
          : isExisting ? 'Đã lưu bản nháp' : 'Đã tạo bản nháp'
      );
      onSaved();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Lỗi không xác định khi lưu';
      setError(msg);
      showToast('error', 'Lưu thất bại — vui lòng thử lại');
    } finally {
      setSaving(false);
    }
  };

  const handleConvert = async () => {
    if (!content.trim()) return;

    setConvertStatus('converting');
    setConvertMessage(null);

    try {
      const options: Partial<ConverterOptions> = {
        preserveFormatting: true,
        style: 'neutral',
      };

      const result = await convertToVietnamese(content, options);

      if (result.status === 'unavailable') {
        setConvertStatus('unavailable');
        setConvertMessage(result.message);
        return;
      }

      setOriginalContent(content);
      setContent(result.text);
      setConvertStatus('done');
      setConvertMessage(result.message);
      showToast('success', 'Đã chuyển đổi nội dung');
    } catch {
      setConvertStatus('idle');
      setConvertMessage('Lỗi khi chuyển đổi. Vui lòng thử lại.');
      showToast('error', 'Chuyển đổi thất bại');
    }
  };

  const handleRevertConvert = () => {
    if (originalContent) {
      setContent(originalContent);
      setOriginalContent(null);
      setConvertStatus('idle');
      setConvertMessage(null);
      showToast('info', 'Đã khôi phục nội dung gốc');
    }
  };

  const canPublish = content.trim().length > 0 && title.trim().length > 0 && !saving;
  const canSaveDraft = canPublish;
  const converterAvailable = isConverterAvailable();

  return (
    <div className="fixed inset-0 z-[80] flex items-start justify-center overflow-y-auto bg-black/40 p-4 sm:p-8">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl my-4 sm:my-8 flex flex-col" style={{ maxHeight: 'calc(100vh - 2rem)' }}>
        {/* Header */}
        <div className="flex items-center justify-between border-b border-gray-100 px-6 py-4 shrink-0">
          <div className="flex items-center gap-3">
            <h2 className="font-bold text-gray-900">
              {isExisting ? 'Chỉnh sửa chương' : 'Thêm chương mới'}
            </h2>
            {dirty && (
              <span className="flex items-center gap-1 text-xs text-amber-600 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                Chưa lưu
              </span>
            )}
            {status === 'published' && !dirty && (
              <span className="flex items-center gap-1 text-xs text-brand-600 font-medium">
                <CheckCircle2 className="h-3 w-3" /> Đã xuất bản
              </span>
            )}
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500 transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Mode tabs */}
        <div className="flex items-center gap-1 px-6 pt-4 border-b border-gray-100 shrink-0">
          <button
            onClick={() => setMode('edit')}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              mode === 'edit' ? 'border-brand-600 text-brand-600' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Pencil className="h-4 w-4" /> Soạn thảo
          </button>
          <button
            onClick={() => setMode('preview')}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              mode === 'preview' ? 'border-brand-600 text-brand-600' : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Eye className="h-4 w-4" /> Xem trước
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-6 py-5">
          {/* Error banner */}
          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 rounded-lg px-4 py-3 flex items-start gap-2">
              <AlertCircle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-red-700 font-medium">{error}</p>
                <p className="text-xs text-red-500 mt-1">Vui lòng sửa lỗi và thử lại.</p>
              </div>
              <button onClick={() => setError(null)} className="text-red-400 hover:text-red-600">
                <X className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* Convert notice */}
          {convertMessage && (
            <div className={`mb-4 rounded-lg px-4 py-3 flex items-start gap-2 text-sm ${
              convertStatus === 'unavailable'
                ? 'bg-gray-50 border border-gray-200 text-gray-600'
                : convertStatus === 'done'
                ? 'bg-brand-50 border border-brand-200 text-brand-700'
                : 'bg-amber-50 border border-amber-200 text-amber-700'
            }`}>
              <Sparkles className="h-4 w-4 shrink-0 mt-0.5" />
              <span className="flex-1">{convertMessage}</span>
              {convertStatus === 'done' && originalContent && (
                <button onClick={handleRevertConvert} className="flex items-center gap-1 text-xs font-medium hover:underline shrink-0">
                  <RotateCcw className="h-3 w-3" /> Hoàn tác
                </button>
              )}
            </div>
          )}

          {mode === 'edit' ? (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Thứ tự</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={chapterOrder}
                    onChange={(e) => setChapterOrder(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none transition-all text-sm bg-white"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Tiêu đề chương</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Ví dụ: Chương 1: Khởi đầu"
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none transition-all text-sm bg-white"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-sm font-medium text-gray-700">Nội dung chương</label>
                  <button
                    onClick={handleConvert}
                    disabled={!content.trim() || convertStatus === 'converting' || !converterAvailable}
                    className="flex items-center gap-1.5 text-xs font-medium text-brand-600 hover:text-brand-700 disabled:text-gray-300 disabled:cursor-not-allowed transition-colors"
                    title={converterAvailable ? 'Chuyển đổi sang tiếng Việt tự nhiên' : 'Công cụ chưa kích hoạt'}
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    {convertStatus === 'converting' ? 'Đang chuyển đổi...' : 'Chuyển đổi tiếng Việt'}
                  </button>
                </div>
                <textarea
                  ref={textAreaRef}
                  value={content}
                  onChange={(e) => { setContent(e.target.value); setDirty(true); }}
                  onPaste={handlePaste}
                  rows={18}
                  className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none transition-all text-[15px] leading-relaxed bg-white resize-y font-serif"
                  placeholder="Dán hoặc nhập nội dung chương tại đây. Đoạn văn cách nhau bằng một dòng trống. Xuống dòng và dấu câu sẽ được giữ nguyên."
                />
                <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
                  <span className="flex items-center gap-1">
                    <FileText className="h-3 w-3" /> {stats.words.toLocaleString('vi-VN')} từ
                  </span>
                  <span>{stats.paragraphs.toLocaleString('vi-VN')} đoạn</span>
                  <span>{stats.characters.toLocaleString('vi-VN')} ký tự</span>
                </div>
              </div>
            </div>
          ) : (
            <ChapterPreview title={title} content={content} />
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between gap-3 border-t border-gray-100 px-6 py-4 shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors"
          >
            {dirty ? 'Hủy' : 'Đóng'}
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleSave('draft')}
              disabled={!canSaveDraft}
              className="flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <Save className="h-4 w-4" />
              {saving ? 'Đang lưu...' : 'Lưu nháp'}
            </button>
            <button
              onClick={() => handleSave('publish')}
              disabled={!canPublish}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="h-4 w-4" />
              {saving ? 'Đang xuất bản...' : status === 'published' ? 'Cập nhật & xuất bản' : 'Xuất bản'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Preview component ---
function ChapterPreview({ title, content }: { title: string; content: string }) {
  const paragraphs = useMemo(() => {
    return content.split(/\n\s*\n/).filter((p) => p.trim().length > 0);
  }, [content]);

  return (
    <article className="max-w-2xl mx-auto">
      <h1 className="text-xl sm:text-2xl font-bold text-gray-900 mb-6 pb-4 border-b border-gray-100">
        {title || '(Chưa có tiêu đề)'}
      </h1>
      {paragraphs.length === 0 ? (
        <p className="text-gray-400 italic text-center py-12">Chưa có nội dung để xem trước</p>
      ) : (
        <div className="space-y-4">
          {paragraphs.map((para, i) => (
            <p key={i} className="text-[16px] leading-[1.85] text-gray-800 whitespace-pre-line font-serif">
              {para.trim()}
            </p>
          ))}
        </div>
      )}
    </article>
  );
}

// --- Helpers ---
function formatSupabaseError(err: { message?: string; code?: string }, fallback: string): string {
  if (err.code === '42501') {
    return 'Bạn không có quyền thực hiện thao tác này. Vui lòng đăng nhập bằng tài khoản quản trị.';
  }
  if (err.code === '23505') {
    return 'Chương với thứ tự này đã tồn tại. Vui lòng chọn số thứ tự khác.';
  }
  return err.message || fallback;
}
