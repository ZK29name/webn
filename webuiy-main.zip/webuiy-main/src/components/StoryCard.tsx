import { Link } from 'react-router-dom';
import { BookOpen } from 'lucide-react';
import type { Story } from '@/lib/types';
import { STORY_STATUS_LABELS, STORY_STATUS_COLORS } from '@/lib/types';

interface StoryCardProps {
  story: Story;
  chapterCount?: number;
}

export default function StoryCard({ story, chapterCount }: StoryCardProps) {
  return (
    <Link
      to={`/truyen/${story.slug}`}
      className="group flex flex-col bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg hover:border-brand-200 hover:-translate-y-0.5 transition-all duration-200"
    >
      <div className="relative aspect-[3/4] bg-gradient-to-br from-gray-50 to-gray-100 overflow-hidden">
        {story.cover_url ? (
          <img
            src={story.cover_url}
            alt={story.title}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-300">
            <BookOpen className="h-12 w-12" />
          </div>
        )}
        <span
          className={`absolute top-2 left-2 px-2 py-0.5 rounded text-xs font-medium shadow-sm ${STORY_STATUS_COLORS[story.status]}`}
        >
          {STORY_STATUS_LABELS[story.status]}
        </span>
      </div>

      <div className="p-3 flex flex-col flex-1">
        <h3 className="font-semibold text-sm text-gray-900 line-clamp-2 group-hover:text-brand-600 transition-colors mb-1 leading-snug">
          {story.title}
        </h3>
        <p className="text-xs text-gray-500 mb-2 line-clamp-1">{story.author}</p>
        {chapterCount !== undefined && (
          <p className="text-xs text-gray-400 mt-auto flex items-center gap-1">
            <BookOpen className="h-3 w-3" />
            {chapterCount} chương
          </p>
        )}
      </div>
    </Link>
  );
}
