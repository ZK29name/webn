import { Link } from 'react-router-dom';
import { BookOpen, Github, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <BookOpen className="h-6 w-6 text-emerald-400" />
              <span className="text-lg font-bold text-white">Truyện Việt</span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              Nền tảng đọc truyện tiếng Việt, ưu tiên trải nghiệm đọc thoải mái
              trên mọi thiết bị.
            </p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-3 text-sm">Khám phá</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/" className="hover:text-emerald-400 transition-colors">Trang chủ</Link></li>
              <li><Link to="/truyen" className="hover:text-emerald-400 transition-colors">Tất cả truyện</Link></li>
              <li><Link to="/the-loai" className="hover:text-emerald-400 transition-colors">Thể loại</Link></li>
              <li><Link to="/truyen?status=completed" className="hover:text-emerald-400 transition-colors">Truyện hoàn thành</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-3 text-sm">Tài khoản</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/dang-nhap" className="hover:text-emerald-400 transition-colors">Đăng nhập</Link></li>
              <li><Link to="/dang-ky" className="hover:text-emerald-400 transition-colors">Đăng ký</Link></li>
              <li><Link to="/thu-vien" className="hover:text-emerald-400 transition-colors">Thư viện cá nhân</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-gray-500">
          <p>© 2026 Truyện Việt. Nội dung mẫu chỉ phục vụ kiểm tra.</p>
          <p className="flex items-center gap-1.5">
            Xây dựng với <Heart className="h-4 w-4 text-emerald-400" /> bằng React &amp; Supabase
          </p>
        </div>
      </div>
    </footer>
  );
}
