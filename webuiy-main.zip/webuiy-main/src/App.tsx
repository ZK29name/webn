import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/lib/auth';
import Layout from '@/components/Layout';
import { ProtectedRoute, AdminRoute } from '@/components/ProtectedRoute';
import HomePage from '@/pages/HomePage';
import StoryListPage from '@/pages/StoryListPage';
import StoryDetailPage from '@/pages/StoryDetailPage';
import ReadChapterPage from '@/pages/ReadChapterPage';
import GenresPage from '@/pages/GenresPage';
import LoginPage from '@/pages/LoginPage';
import SignupPage from '@/pages/SignupPage';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import ResetPasswordPage from '@/pages/ResetPasswordPage';
import LibraryPage from '@/pages/LibraryPage';
import AdminPage from '@/pages/AdminPage';
import NotFoundPage from '@/pages/NotFoundPage';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="truyen" element={<StoryListPage />} />
            <Route path="truyen/:slug" element={<StoryDetailPage />} />
            <Route path="truyen/:slug/chuong/:chapterId" element={<ReadChapterPage />} />
            <Route path="the-loai" element={<GenresPage />} />
            <Route path="dang-nhap" element={<LoginPage />} />
            <Route path="dang-ky" element={<SignupPage />} />
            <Route path="quen-mat-khau" element={<ForgotPasswordPage />} />
            <Route path="dat-lai-mat-khau" element={<ResetPasswordPage />} />
            <Route
              path="thu-vien"
              element={
                <ProtectedRoute>
                  <LibraryPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="admin"
              element={
                <AdminRoute>
                  <AdminPage />
                </AdminRoute>
              }
            />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
