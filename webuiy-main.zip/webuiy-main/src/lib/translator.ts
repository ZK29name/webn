/**
 * Translation converter architecture.
 *
 * This module provides the interface for a future Vietnamese conversion tool
 * that could translate raw text into natural Vietnamese. The actual AI/API
 * integration is NOT implemented yet — this is a stub that returns the
 * original text unchanged, with a clear status indicating the converter
 * is not yet available.
 *
 * When the paid API is added later, implement `convertToVietnamese` in
 * `converters/aiConverter.ts` and swap the implementation here.
 * The component layer (ChapterEditor) calls this module and does not
 * need to change.
 */

export type ConverterStatus = 'unavailable' | 'converting' | 'done' | 'error';

export interface ConverterResult {
  text: string;
  status: ConverterStatus;
  message: string;
}

export interface ConverterOptions {
  /** Preserve original paragraph structure and line breaks */
  preserveFormatting: boolean;
  /** Target dialect style */
  style: 'northern' | 'southern' | 'neutral';
}

/**
 * Stub implementation — returns original text unchanged.
 * Replace with actual API call when the translation service is configured.
 */
export async function convertToVietnamese(
  text: string,
  _options?: Partial<ConverterOptions>
): Promise<ConverterResult> {
  return {
    text,
    status: 'unavailable',
    message: 'Công cụ chuyển đổi sang tiếng Việt chưa được kích hoạt. Nội dung gốc được giữ nguyên.',
  };
}

/**
 * Checks whether the converter is available (i.e. an API key is configured).
 * Currently always returns false.
 */
export function isConverterAvailable(): boolean {
  return false;
}
