/**
 * Text processing utilities for the chapter editor.
 * Preserves paragraph order, line breaks, dialogue markers, and punctuation
 * when the user pastes multi-paragraph text.
 */

/**
 * Normalizes raw text from paste or manual input:
 * - Converts CRLF to LF
 * - Removes trailing whitespace per line
 * - Collapses 3+ consecutive blank lines into max 1 (paragraph separator)
 * - Preserves single newlines within paragraphs (intentional line breaks)
 * - Preserves leading indentation for dialogue lines (e.g. Vietnamese convention)
 * - Trims leading/trailing whitespace from the whole text
 */
export function normalizePastedText(raw: string): string {
  return raw
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/[ \t]+$/gm, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Counts words in Vietnamese text.
 * Vietnamese words are typically space-separated syllables, so this
 * counts whitespace-separated tokens. For dialogue-heavy text with
 * em-dashes, it still gives a reasonable approximation.
 */
export function countWords(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).filter(Boolean).length;
}

/**
 * Counts paragraphs (blocks separated by blank lines).
 */
export function countParagraphs(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\n\s*\n/).filter((p) => p.trim().length > 0).length;
}

/**
 * Estimates character count (excluding leading/trailing whitespace).
 */
export function countCharacters(text: string): number {
  return text.trim().length;
}

/**
 * Truncates text to a max character count, ensuring it doesn't cut
 * mid-word. Appends an ellipsis if truncated.
 * Used for preview snippets, not for stored content.
 */
export function truncateForPreview(text: string, maxChars: number): string {
  if (text.length <= maxChars) return text;
  const slice = text.slice(0, maxChars);
  const lastSpace = slice.lastIndexOf(' ');
  const cutPoint = lastSpace > maxChars * 0.8 ? lastSpace : maxChars;
  return slice.slice(0, cutPoint).trimEnd() + '…';
}
