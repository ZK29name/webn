export type StoryStatus = 'ongoing' | 'completed' | 'hiatus';
export type ChapterStatus = 'draft' | 'published';
export type UserRole = 'reader' | 'admin';

export interface Genre {
  id: string;
  name: string;
  slug: string;
  description: string | null;
}

export interface Story {
  id: string;
  title: string;
  slug: string;
  author: string;
  description: string | null;
  cover_url: string | null;
  status: StoryStatus;
  is_hidden: boolean;
  created_at: string;
  updated_at: string;
}

export interface StoryWithGenres extends Story {
  genres: Genre[];
  chapter_count?: number;
}

export interface Chapter {
  id: string;
  story_id: string;
  title: string;
  content: string;
  chapter_order: number;
  status: ChapterStatus;
  word_count: number;
  created_at: string;
  updated_at: string;
}

export interface Profile {
  id: string;
  username: string;
  role: UserRole;
  created_at: string;
}

export interface Bookmark {
  story_id: string;
  user_id: string;
  created_at: string;
  stories: Story;
}

export interface ReadingHistoryEntry {
  id: string;
  user_id: string;
  story_id: string;
  chapter_id: string;
  read_at: string;
  stories: Story;
  chapters: Chapter;
}

export const STORY_STATUS_LABELS: Record<StoryStatus, string> = {
  ongoing: 'Đang ra',
  completed: 'Hoàn thành',
  hiatus: 'Tạm dừng',
};

export const STORY_STATUS_COLORS: Record<StoryStatus, string> = {
  ongoing: 'bg-emerald-100 text-emerald-700',
  completed: 'bg-blue-100 text-blue-700',
  hiatus: 'bg-amber-100 text-amber-700',
};

export const CHAPTER_STATUS_LABELS: Record<ChapterStatus, string> = {
  draft: 'Bản nháp',
  published: 'Đã xuất bản',
};
